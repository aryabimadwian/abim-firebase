<?php
ini_set('date.timezone', 'Asia/Jakarta');
$databaseURL = "https://pengukuran-partikulat-default-rtdb.asia-southeast1.firebasedatabase.app/";

// $databaseURL = "https://abim-d50ef-default-rtdb.firebaseio.com/";