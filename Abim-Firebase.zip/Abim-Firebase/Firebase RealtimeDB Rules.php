{
"rules": {
".read": true,
".write": true
}
}